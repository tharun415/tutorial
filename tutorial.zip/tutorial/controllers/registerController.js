/* Created by Teja on 28/1/2017. */

        app.controller("registerController",registerController);
        registerController.$inject=["$scope","$location"];
        function registerController($scope,$location){
            $scope.var_three="Welcome to Register Page";


        }

