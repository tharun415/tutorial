/* Created by Teja on 28/1/2017. */

    var app=angular.module("app",["ui.router","ngStorage","ngMessages"]);
